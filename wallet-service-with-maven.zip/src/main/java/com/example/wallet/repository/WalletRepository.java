package com.example.wallet.repository;

import com.example.wallet.model.Wallet;
import io.micronaut.data.annotation.Repository;
import io.micronaut.data.repository.CrudRepository;

@Repository
public interface WalletRepository extends CrudRepository<Wallet, Long> {
}
