package com.example.wallet;

import io.micronaut.runtime.Micronaut;

public class WalletApplication {
    public static void main(String[] args) {
        Micronaut.run(WalletApplication.class);
    }
}
