package com.example.wallet.controller;

import com.example.wallet.model.Wallet;
import com.example.wallet.service.WalletService;
import io.micronaut.http.annotation.*;
import jakarta.inject.Inject;
import java.util.Optional;

@Controller("/wallets")
public class WalletController {

    @Inject
    WalletService walletService;

    @Post
    public Wallet createWallet(@Body Wallet wallet) {
        return walletService.createWallet(wallet);
    }

    @Get("/{id}")
    public Optional<Wallet> getWallet(@PathVariable Long id) {
        return walletService.getWallet(id);
    }
}
